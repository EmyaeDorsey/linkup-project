//
//  LinkupApp.swift
//  Linkup
//
//  Created by Emyae Dorsey on 11/8/24.
//

import SwiftUI

@main
struct LinkupApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
