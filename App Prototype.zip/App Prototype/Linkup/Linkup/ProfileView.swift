//
//  ProfileView.swift
//  Linkup
//
//  Created by Emyae Dorsey on 11/8/24.
//

import SwiftUI

struct ProfileView: View {
    var body: some View {
        Text("Profile View")
    }
}

#Preview {
    ProfileView()
}
