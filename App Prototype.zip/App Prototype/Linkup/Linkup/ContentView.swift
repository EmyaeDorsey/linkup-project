//
//  ContentView.swift
//  Linkup
//
//  Created by Emyae Dorsey on 11/8/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView(selection: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Selection@*/.constant(1)/*@END_MENU_TOKEN@*/) {
            CameraView().tabItem { Text("Camera") }.tag(1)
            SearchView().tabItem { Text("Search") }.tag(2)
            HomeView().tabItem { Text("Home") }.tag(3)
            MessageView().tabItem { Text("Message") }.tag(4)
            ProfileView().tabItem { Text("Profile") }.tag(5)
           
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
