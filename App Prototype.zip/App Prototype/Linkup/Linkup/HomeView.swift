//
//  HomeView.swift
//  Linkup
//
//  Created by Emyae Dorsey on 11/8/24.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        Text("Home View")
    }
}

#Preview {
    HomeView()
}
