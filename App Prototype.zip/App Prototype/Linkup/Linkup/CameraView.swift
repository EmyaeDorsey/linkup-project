//
//  CameraView.swift
//  Linkup
//
//  Created by Emyae Dorsey on 11/8/24.
//

import SwiftUI

struct CameraView: View {
    var body: some View {
        Text("CameraView")
    }
}

#Preview {
    CameraView()
}
